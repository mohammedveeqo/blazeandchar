Blaze & Char — Supplier bundle
================================

Everything a pouch supplier or designer needs, in one folder.

WHAT'S IN HERE
--------------

Pouch design reference (open in any web browser)
-------------------------------------------------
- blaze-pouch-v7-pair-v02-chilli-honey.html
  The picked colour-way: red Tandoori + gold Masala.
  Press Cmd+P (Mac) or Ctrl+P (Windows) -> Save as PDF to send.
  Prints as 2 pages of A4 landscape: page 1 = front pair,
  page 2 = back pair. Both SKUs side-by-side on each page.

- blaze-pouch-v7-final.html
  Same design, canonical master. Keep as archive.

Spec sheet for quoting (open in any web browser)
-------------------------------------------------
- blaze-pouch-supplier-brief.html
  Full pouch spec: dimensions, material, finish, closure,
  MOQ, colour system, print process, what we need back.
  Press Cmd+P (Mac) or Ctrl+P (Windows) -> Save as PDF.
  Prints as 3 pages of A4 portrait.

Logo & identity
---------------
- blaze-logo-set.html    — full brand-guide page, open in browser
- blaze-monogram.svg     — primary & mark, tandoori red on transparent
- blaze-monogram-reversed.svg  — cream on tandoori red
- blaze-logo-horizontal.svg    — monogram + wordmark lockup (light bg)
- blaze-logo-horizontal-reversed.svg  — same lockup on tandoori red
- blaze-logo-stacked.svg       — monogram above wordmark, square format
- blaze-wordmark.svg           — "Blaze & Char" wordmark only, no mark
- favicon.svg                  — tuned for 16-32px rendering
- wales-silhouette.svg         — the Welsh coast mark, solid green

HOW TO USE THIS
---------------

1. Email blaze-pouch-supplier-brief.html (saved as PDF) to your
   supplier to get a quote.
2. Email blaze-pouch-v7-pair-v02-chilli-honey.html (saved as PDF)
   as visual reference for the artwork.
3. Keep the SVGs — a print designer will use them as source assets
   when building the CMYK print-ready PDFs.

FONTS USED IN THE DESIGN
------------------------
- Fraunces (display)   — SIL OFL, free for commercial use
- Inter (body)         — SIL OFL, free for commercial use
- JetBrains Mono (mono) — SIL OFL, free for commercial use

All available from fonts.google.com.

NEXT STEPS AFTER QUOTING
------------------------
Before printing:
- Buy EAN-13 barcode from GS1 UK (~£50 starter licence)
- Lab-test the recipe for real nutrition values
- Confirm "halal" chain-of-custody docs with your butcher
- Approve a press-proof (physical sample print) before
  committing to the full run
